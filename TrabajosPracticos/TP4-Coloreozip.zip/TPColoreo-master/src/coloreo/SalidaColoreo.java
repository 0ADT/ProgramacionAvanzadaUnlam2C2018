package coloreo;

import java.util.List;

public class SalidaColoreo {

	private List<Nodo> grafoColoreado;
	private int cantDeColorUsuados;
	
	public SalidaColoreo(List<Nodo> grafoColoreado, int cantDeColorUsuados) {
		this.grafoColoreado = grafoColoreado;
		this.cantDeColorUsuados = cantDeColorUsuados;
	}
	
	
}
